


<html>
<head>
</head>
<body>
Dashboard
    
</body>
</html>


<style>

.form-part-login{display:none; height:300px; width:300px; border:1px solid #000;}
.form-part-loading{display:block; height:300px; width:300px; border:1px solid #000;}

</style>




<script src="/Assets/js/jquery-3.5.1.min.js"></script>
<script src="/Assets/js/usefullfunctions.js"></script>

<script src="/App/Scripts/auth_script.js"></script>

<script src="/Assets/js/main.js"></script>
<!--
<script  async  src="/Assets/plugins/fp.min.js"  onload="initFingerprintJS()"></script>
<script>
  function initFingerprintJS() {
    FingerprintJS.load().then(fp => {
      // The FingerprintJS agent is ready.
      // Get a visitor identifier when you'd like to.
      fp.get().then(result => {
        // This is the visitor identifier:
        const visitorId = result.visitorId;
        console.log(visitorId);
      });
    });
  }
  </script>
-->

<!---if ('a' in ob)-->























