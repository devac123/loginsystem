<?php
 

// Database
define ( 'DB_HOST', 'localhost:3306' );
define ( 'DB_USER', 'root' );
define ( 'DB_PASSWORD', '1234' );
define ( 'DB_DB', 'devocmsv1' );
 
?>