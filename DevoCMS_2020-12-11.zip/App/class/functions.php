<?php

function objProp($data)
{
    $ret = "";

    if(isset($data))
    {
        $ret = $data;
    }
    else
    {
        $ret = "Null";
    }
     return $ret;
}







//Database function -------------------------------------------------------------------------------------------------



?>
