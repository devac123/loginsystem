


<html>
<head>
</head>
<body>

    <div class="form-login">
        <div class="form-part-login" data-group-con="login">
            
            <div class="input-con">
              <input value="mandygenius" type="text" placeholder="Username" data-group="login" data-key="username" /><br/>
              <span class="input-message"></span>
            </div>

            <div class="input-con">
                <input value="123456789" type="text" placeholder="Passowrd" data-group="login" data-key="password" /><br/>
                <span class="input-message"></span>
            </div>
          
                   
          
            <input value="Login" type="button" data-group-action="login" /><br/>
            <span class="" data-group-message="login"></span>
        </div>
        <div class="form-part-loading">
        <span class="loading-message">Please Wait <br/>we are checking your login details</span>
        </div>
    </div>



</body>
</html>


<style>

.form-part-login{display:none; height:300px; width:300px; border:1px solid #000;}
.form-part-loading{display:block; height:300px; width:300px; border:1px solid #000;}

</style>




<script src="/Assets/js/jquery-3.5.1.min.js"></script>
<script src="/App/Scripts/auth_script.js"></script>
<script src="/Assets/js/usefullfunctions.js"></script>
<script src="/Assets/js/main.js"></script>

<script>

  $(document).on('click','*[data-group-action]',function(){

      var group = $(this).attr('data-group-action');
      var reqObj = {};

      var dataObj={}
      $('*[data-group="'+ group +'"]').each(function()
      {
        dataObj[$(this).attr('data-key')] = $(this).val();
      });

      var headerObj={}
      headerObj["token"] = GetToken();
      headerObj["deviceFP"] = GetDeviceFP();


      reqObj["Header"] = headerObj;
      reqObj["Data"] = dataObj;
   
      
    return $.ajax({
        url: '/App/Controller/auth_controller.php',
        type: 'post',
        data: { "LoginCheck": JSON.stringify(reqObj) },
        success: function(response) 
        {
          res = response.replace(/(\r\n|\n|\r)/gm, "");
          consolelog("Ajax Success:"+ res);
               
        },
        error:function(response){
            consolelog("Ajax Error:" + response); 
            
        }
       });
      
      

      

  });



  </script>




















<!--
<script  async  src="/Assets/plugins/fp.min.js"  onload="initFingerprintJS()"></script>
<script>
  function initFingerprintJS() {
    FingerprintJS.load().then(fp => {
      // The FingerprintJS agent is ready.
      // Get a visitor identifier when you'd like to.
      fp.get().then(result => {
        // This is the visitor identifier:
        const visitorId = result.visitorId;
        console.log(visitorId);
      });
    });
  }
  </script>
-->

<!---if ('a' in ob)-->

<script>

  function Startup()
  {
    $('.form-part-loading').css('display','none');
    $('.form-part-login').css('display','block');

  }


  </script>





















